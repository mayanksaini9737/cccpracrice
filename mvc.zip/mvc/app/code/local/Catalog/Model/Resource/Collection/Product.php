<?php

class Catalog_Model_Resource_Collection_Product extends Core_Model_Resource_Collection_Abstract
{

}
?>
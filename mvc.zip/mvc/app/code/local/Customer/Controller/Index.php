<?php
class Customer_Controller_Index
{
    public function newAction()
    {
        echo "from customer/index/new";
    }
    public function listAction()
    {
        echo "from customer/index/list";
    }
    public function saveAction()
    {
        echo "from customer/index/save";
    }
    public function deleteAction()
    {
        echo "from customer/index/delete";
    }
}
?>
<?php
class Customer_Controller_Quot_Address
{
    public function newAction()
    {
        echo "from customer/quot_address/new";
    }
    public function listAction()
    {
        echo "from customer/quot_address/list";
    }
    public function saveAction()
    {
        echo "from customer/quot_address/save";
    }
    public function deleteAction()
    {
        echo "from customer/quot_address/delete";
    }
}
?>
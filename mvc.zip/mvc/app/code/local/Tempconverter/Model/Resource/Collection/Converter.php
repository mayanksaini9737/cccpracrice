<?php 
class Tempconverter_Model_Resource_Collection_Converter extends Core_Model_Resource_Collection_Abstract
{
    
}
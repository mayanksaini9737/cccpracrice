<?php
class Sales_Model_Quote extends Core_Model_Abstract
{
    public function init()
    {
        $this->_modelClass = 'sales/quote';
        $this->_resourceClass = 'Sales_Model_Resource_Quote';
        $this->_collectionClass = 'Sales_Model_Resource_Collection_Quote';
    }
    public function initQuote()
    {
        $quoteId = Mage::getSingleton("core/session")->get("quote_id");
        $this->load($quoteId);
        if(!$this->getId()){
            $quote = Mage::getModel("sales/quote")
                ->setData(["tax_percent" => 8, "grand_total" => 0])
                ->save();
            Mage::getSingleton("core/session")->set("quote_id", $quote->getId());
            $quoteId = $quote->getId();
            $this->load($quoteId);
        }
        return $this;
    }

    public function getItemCollection()
    {
        return Mage::getModel('sales/quote_item')->getCollection()
            ->addFieldToFilter('quote_id', $this->getId());
    }
    public function getCustomer()
    {
        return Mage::getModel('sales/quote_customer')->getCollection()
            ->addFieldToFilter('quote_id', $this->getId())->getFirstItem();
    }

    protected function _beforeSave()
    {
        $grandTotal = 0;
        foreach ($this->getItemCollection()->getData() as $_item) {
            $grandTotal += (int)$_item->getRowTotal();
        }
        if ($this->getTaxPercent()) {
            $tax = round($grandTotal / $this->getTaxPercent(), 2);
            $grandTotal = $grandTotal + $tax;
        }
        $this->addData('grand_total', $grandTotal);
    }

    public function addProduct($request)
    {
        $this->initQuote();
        $quoteId = $this->getId();
        if (isset($quoteId)) {
            Mage::getModel('sales/quote_item')->addItem($this, $request['product_id'], $request['qty']);
        }
        $this->save();
    }

    public function updateProduct($request)
    {
        $this->initQuote();
        $quoteId = $this->getId();
        if (isset($quoteId)) {
            Mage::getModel('sales/quote_item')->updateItem($this, $request['product_id'], $request['qty']);
        }
        $this->save();
    }
    public function deleteProduct($request)
    {
        $this->initQuote();
        $quoteId = $this->getId();
        if (isset($quoteId)) {
            Mage::getModel('sales/quote_item')->deleteItem($this, $request['product_id']);
        }
        $this->save();
    }

    public function convert()
    {
        $this->initQuote();
        if ($this->getId()) {
            $order = Mage::getModel('sales/order')
            ->setData($this->getData())->save();
            foreach ($this->getItemCollection()->getData() as $_item) {
                Mage::getModel('sales/order_item')
                    ->setData($_item->getData())
                    ->addData('order_id', $order->getId())
                    ->save();
                $this->deleteProduct(['product_id'=>$_item->getProductId()]);
            }
            Mage::getModel('sales/order_customer')
                ->setData($this->getCustomer()->getData())
                ->addData('order_id', $order->getId())->save();
        }

        $this->setData($this->getData())
            ->addData('order_id', $order->getId())
            ->save();

        Mage::getSingleton('core/session')
            ->remove('quote_id');
        
        return $order;
    }

    public function addAddress($addressData, $paymentData, $shippingData)
    {
        $this->initQuote();
        $quoteId = $this->getId();
        
        if (isset($quoteId)) {
            Mage::getModel('sales/quote_customer')->saveAddress($this, $addressData);
            $payment = Mage::getModel('sales/quote_payment')->savePayment($this, $paymentData);
            $shipping = Mage::getModel('sales/quote_shipping')->saveShipping($this, $shippingData);
        }
        $this->setData($this->getData())
            ->addData('payment_id', $payment->getPaymentId())
            ->addData('shipping_id', $shipping->getShippingId())
            ->save();
        return $this;
    }
}


<?php 
class Sales_Model_Order extends Core_Model_Abstract
{
    public function init()
    {
        $this->_modelClass = 'sales/order';
        $this->_resourceClass = 'Sales_Model_Resource_Order';
        $this->_collectionClass = 'Sales_Model_Resource_Collection_Order';
    }

    public function _beforeSave()
    {
        $this->removeData('quote_id')
            ->removeData('payment_id')
            ->removeData('shipping_id')
            ->removeData('order_id');

        $orderNumber = time();
        $this->addData('order_number', $orderNumber);
    }
}
